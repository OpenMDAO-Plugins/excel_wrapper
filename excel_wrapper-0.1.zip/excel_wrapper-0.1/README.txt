

README.txt file for excel_wrapper.

To view the Sphinx documentation for this distribution, type:

plugin docs excel_wrapper

